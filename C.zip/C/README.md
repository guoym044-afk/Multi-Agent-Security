# Multi-Agent Security

A course practice project for **AI Safety and Ethics**.

This project studies security risks in multi-agent AI collaboration. It simulates malicious-agent attacks, compares defense strategies, and evaluates the tradeoff between safety and task completion.

Repository: <https://github.com/guoym044-afk/Multi-Agent-Security>

## Project Overview

Multi-agent systems can divide a complex task across multiple agents, but they also introduce new attack surfaces:

- malicious agents can inject harmful instructions into the collaboration process
- one compromised agent can influence downstream agents
- sensitive information may be forwarded across agent boundaries
- safety checks can be bypassed through indirect instructions or collusion

This project focuses on a compact attack-defense-evaluation loop:

1. Simulate multi-agent collaboration.
2. Inject malicious messages or malicious-agent behavior.
3. Apply defense strategies such as filtering, safety judging, and permission control.
4. Measure attack success, privacy leakage, task completion, blocking rate, and false positives.

## Current Status

This repository now contains two reproducible tracks:

1. **Simulated benchmark**: `data/sample_logs.json` contains hand-written experiment logs for presentation-friendly baseline results.
2. **Minimal runnable demo**: `src/demo.py` reads `data/attack_cases.json` and `data/benign_cases.json`, simulates a Planner / Researcher / Writer / Reviewer / MaliciousAgent message flow, applies defense rules, and writes `data/demo_logs.json`.

The demo is intentionally deterministic and dependency-free. It is not a full LLM agent runtime, but it turns the project from static evaluation material into a runnable attack-defense-evaluation loop with benign controls for measuring false positives.

## Repository Structure

```text
.
├── README.md
├── data/
│   ├── attack_cases.json
│   ├── benign_cases.json
│   ├── demo_logs.json
│   ├── interface_examples/
│   │   ├── agent_trace_message.json
│   │   ├── defense_decision.json
│   │   ├── defense_request.json
│   │   └── evaluator_log.json
│   └── sample_logs.json
├── docs/
│   └── integration_interfaces.md
├── ppt_materials/
│   ├── Multi-Agent-Security-Presentation.pptx
│   ├── attack_cases.md
│   ├── attack_cases_ppt_notes.md
│   ├── benign_controls.md
│   ├── evaluation.md
│   └── final_presentation_outline.md
├── results/
│   ├── category_metrics.csv
│   ├── failure_cases.csv
│   ├── metrics.csv
│   ├── metrics_summary.md
│   ├── demo/
│   │   ├── category_metrics.csv
│   │   ├── failure_cases.csv
│   │   ├── metrics.csv
│   │   ├── metrics_summary.md
│   │   └── figures/
│   │       ├── metrics.png
│   │       └── metrics.svg
│   └── figures/
│       ├── metrics.png
│       └── metrics.svg
├── src/
│   ├── demo.py
│   └── evaluate.py
└── tests/
    └── test_pipeline.py
```

## Quick Start

All scripts only require Python 3 and do not use third-party packages.

Evaluate the simulated benchmark:

```bash
python3 src/evaluate.py
```

Generate demo logs from the attack case library:

```bash
python3 src/demo.py
```

Evaluate the generated demo logs without overwriting the benchmark outputs:

```bash
python3 src/evaluate.py --input data/demo_logs.json --output-dir results/demo
```

Evaluate a custom log file:

```bash
python3 src/evaluate.py --input path/to/logs.json --output-dir results/custom
```

Run the regression tests:

```bash
python3 tests/test_pipeline.py
```

The default evaluator reads:

```text
data/sample_logs.json
```

The script writes:

```text
results/metrics.csv
results/category_metrics.csv
results/failure_cases.csv
results/metrics_summary.md
results/figures/metrics.svg
results/figures/metrics.png
```

## Minimal Demo Workflow

The demo simulates this compact workflow:

```text
PlannerAgent -> ResearcherAgent -> WriterAgent -> ReviewerAgent -> FinalOutput
                         ^
                         |
               MaliciousAgent / ExternalDocument
```

It runs each attack case and benign control case under four modes:

| Mode | Meaning |
|---|---|
| `no_defense` | No malicious message inspection |
| `keyword_filter` | Blocks obvious sensitive markers and injection phrases |
| `safety_agent` | Applies broader risk checks by attack category and risk level |
| `permission_control` | Blocks untrusted senders from writing to protected agent roles |

The generated logs are written to:

```text
data/demo_logs.json
```

## Experiment Log Format

Each log entry must include these required fields:

```json
{
  "case_id": "case_001",
  "category": "privacy_leakage",
  "mode": "no_defense",
  "blocked": false,
  "attack_success": true,
  "privacy_leak": true,
  "task_completed": true,
  "false_positive": false
}
```

The demo also writes optional fields such as `is_attack`, `case_type`, `attack_entry`, `target_agent`, and `blocked_reason`. The evaluator accepts these fields and ignores unknown extras. When `is_attack` is present, attack success and privacy leak rates are computed over attack cases, while false positive rate is computed over benign cases.

## Attack Case Library

The attack case library is stored in:

```text
data/attack_cases.json
```

It contains 20 structured attack cases across five categories:

| Category | Meaning |
|---|---|
| `privacy_leakage` | Attempts to expose sensitive values such as API keys, passwords, user identifiers, or internal fields |
| `prompt_injection` | Attempts to override system instructions, skip validation, or impersonate higher-priority roles |
| `misinformation` | Attempts to pollute the final report with false facts, fake evidence, or misleading metric interpretation |
| `review_bypass` | Attempts to make the reviewer approve unsafe, unsupported, or misleading content |
| `collusion` | Attempts to make multiple agents cooperate in forwarding secrets, hiding failures, or bypassing permissions |

Presentation-ready notes are available in:

```text
ppt_materials/attack_cases.md
ppt_materials/attack_cases_ppt_notes.md
```

## Benign Control Cases

The benign control set is stored in:

```text
data/benign_cases.json
```

It contains normal user requests that should be allowed, including safe mentions of sensitive terms such as API keys, tokens, employee IDs, and passwords. These cases make false positives explicit: for example, a keyword filter may block a harmless request that asks how to redact API keys, while a stronger safety judge should allow it.

## Presentation Materials

Final presentation materials are stored in:

```text
ppt_materials/
```

The main deck is:

```text
ppt_materials/Multi-Agent-Security-Presentation.pptx
```

Supporting Markdown materials include the attack case explanation, benign control notes, evaluation results, and a 10-slide final presentation outline.

## Module Interfaces

Integration contracts for A, B, and D are documented in:

```text
docs/integration_interfaces.md
```

The important rule is that B and D can change their internal implementations, but the final evaluator log should keep the required fields shown in `data/interface_examples/evaluator_log.json`. This keeps `src/evaluate.py`, result tables, and A's PPT material stable.

## Metrics

| Metric | Meaning |
|---|---|
| `attack_success_rate` | Ratio of cases where the malicious goal succeeds |
| `privacy_leak_rate` | Ratio of cases where sensitive information leaks |
| `task_completion_rate` | Ratio of cases where the normal task is completed |
| `defense_block_rate` | Ratio of cases blocked by the defense |
| `false_positive_rate` | Ratio of benign control cases incorrectly blocked when `is_attack` is available |

## Current Simulated Results

| Mode | Attack Success | Privacy Leak | Task Completion | Defense Block | False Positive |
|---|---:|---:|---:|---:|---:|
| No defense | 70% | 50% | 90% | 0% | 0% |
| Keyword filter | 40% | 20% | 80% | 50% | 10% |
| Safety agent | 30% | 10% | 80% | 60% | 20% |
| Permission control | 10% | 0% | 70% | 80% | 30% |

## Interpretation

The simulated results show that defenses reduce attack success and privacy leakage. Permission control performs best in this setup, reducing attack success to 10% and privacy leakage to 0%. However, stronger defenses also reduce task completion and increase false positives, so the final system should balance safety with usability.

## Demo-Generated Results

The deterministic demo produces a separate result set under `results/demo/`.

| Mode | Attack Success | Privacy Leak | Task Completion | Defense Block | False Positive |
|---|---:|---:|---:|---:|---:|
| No defense | 100% | 35% | 69% | 0% | 0% |
| Keyword filter | 45% | 5% | 81% | 54% | 50% |
| Safety agent | 40% | 0% | 92% | 46% | 0% |
| Permission control | 0% | 0% | 54% | 77% | 0% |

These numbers come from the simplified rule-based demo, not from a real LLM deployment. They are useful for showing the complete pipeline and explaining the security-usability tradeoff. The keyword filter has a visible false-positive rate because it blocks benign requests that mention sensitive-token vocabulary in a safe context.

## Category and Failure Analysis

The evaluator now writes:

| File | Purpose |
|---|---|
| `results/category_metrics.csv` | Metrics grouped by case category, including benign controls when present |
| `results/failure_cases.csv` | Cases with attack success, privacy leak, false positive, or task failure |
| `results/metrics_summary.md` | Markdown summary with mode metrics, category metrics, and failure examples |

Use the failure-case table in reports or slides to explain which attacks bypassed a defense and which defenses hurt normal task completion.

## Reproducing Results

1. Run `python3 src/evaluate.py` to reproduce the simulated benchmark.
2. Run `python3 src/demo.py` to regenerate `data/demo_logs.json`.
3. Run `python3 src/evaluate.py --input data/demo_logs.json --output-dir results/demo` to reproduce the demo result set.
4. Run `python3 tests/test_pipeline.py` to verify the demo and evaluator behavior.
5. Use `results/metrics.csv`, `results/category_metrics.csv`, `results/failure_cases.csv`, and `results/figures/metrics.svg` in the final report or presentation.

## Updating With External Logs

1. Export real logs from the multi-agent demo using the same field names.
2. Keep the original benchmark file and save the new run separately, for example `data/real_logs.json`.
3. Run `python3 src/evaluate.py --input data/real_logs.json --output-dir results/real`.
4. Compare `results/`, `results/demo/`, and `results/real/` instead of mixing simulated and real results.

## Limitations

- `data/sample_logs.json` is a simulated benchmark, not evidence from a production multi-agent system.
- `src/demo.py` is a deterministic toy runtime. It does not call real LLMs or external tools.
- The demo includes only a small benign control set; a larger benchmark should add more normal tasks across domains.
- Defense rules are intentionally simple so the full pipeline is easy to inspect and reproduce.
