# B Demo Materials

## 模块定位

B Demo 展示一个最小可运行的多智能体安全闭环。它不调用真实 LLM，而是用确定性 Agent 模拟 Planner、Researcher、Writer、Reviewer 与 MaliciousAgent 之间的消息流，方便稳定复现实验结果。

## 文件对应关系

| 文件 | 作用 |
|---|---|
| `src/agents.py` | 定义 Agent、恶意注入、四种防御策略和日志生成逻辑 |
| `src/run_experiment.py` | 从攻击样例和正常样例生成完整 demo 日志 |
| `data/b_demo_full_logs.json` | B Demo 的完整运行日志 |
| `results/b_demo_metrics.csv` | B Demo 按防御模式统计的指标表 |
| `results/demo/metrics_summary.md` | B Demo 的详细指标、类别分析和失败案例 |
| `results/demo/figures/metrics.png` | B Demo PPT 可用柱状图 |

## Demo 结构图

```text
attack_cases.json + benign_cases.json
        |
        v
src/run_experiment.py
        |
        v
data/b_demo_full_logs.json
        |
        v
src/evaluate.py
        |
        v
results/b_demo_metrics.csv + results/demo/figures/metrics.png
```

## 多 Agent 消息流

```text
PlannerAgent -> ResearcherAgent -> WriterAgent -> ReviewerAgent -> FinalOutput
                         ^
                         |
               MaliciousAgent / ExternalDocument
```

## 防御模式

| Mode | 说明 | 预期效果 |
|---|---|---|
| `no_defense` | 不检查恶意消息 | 作为攻击成功基线 |
| `keyword_filter` | 用关键词拦截敏感信息和明显注入语句 | 能拦截显式攻击，但容易误伤正常请求 |
| `safety_agent` | 按攻击类别、风险等级和危险语义做安全判断 | 安全性和可用性更均衡 |
| `permission_control` | 限制不可信发送者写入受保护 Agent | 安全性最强，但可能降低任务完成率 |

## 当前 Demo 指标

| Mode | Attack Success | Privacy Leak | Task Completion | Defense Block | False Positive |
|---|---:|---:|---:|---:|---:|
| No defense | 100% | 35% | 69% | 0% | 0% |
| Keyword filter | 45% | 5% | 81% | 54% | 50% |
| Safety agent | 40% | 0% | 92% | 46% | 0% |
| Permission control | 0% | 0% | 54% | 77% | 0% |

## PPT 讲解重点

1. 无防御时攻击全部成功，说明多 Agent 链路中的中间消息必须被检查。
2. Keyword filter 可以降低攻击成功率和隐私泄露率，但会把正常讨论 API Key 或 token 脱敏的请求误拦截。
3. Safety agent 在当前 demo 中把隐私泄露率降到 0%，同时保持最高任务完成率。
4. Permission control 把攻击成功率降到 0%，但任务完成率下降，体现安全性与可用性的权衡。
5. `failure_cases.csv` 可以选 2-3 个失败案例放进 PPT，避免只展示总指标。

## 复现实验命令

```bash
python3 src/run_experiment.py
python3 src/evaluate.py --input data/b_demo_full_logs.json --output-dir results/demo --metrics-alias results/b_demo_metrics.csv
python3 tests/test_pipeline.py
```
